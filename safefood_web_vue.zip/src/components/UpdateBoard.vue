
<template>
	<div class="container">
        <nav class="navbar navbar-inverse navbar-fixed-top">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed"
						data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span> <span
							class="icon-bar"></span> <span class="icon-bar"></span> <span
							class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#" style="padding: 5px;">
						<img alt="Brand" src="img/ssafy_logo.png"
						style="max-height: 40px;">
					</a>
				</div>
				<div class="collapse navbar-collapse"
					id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a href="#">공지 사항 <span
								class="sr-only">(current)</span></a></li>
						
						<li class="dropdown" id="menuFood"><a
									class="btn btn-sm dropdown-toggle" href="#"
									data-toggle="dropdown" id="navFood"><span>&nbsp;상품</span>
								</a>
									<div class="dropdown-menu" id="dropdownFood" >
										<ul>
											<li><a href="#" >상품 정보</a></li>
											<li><a href="#" >상품 입력</a></li>
										</ul>
									</div>
						</li>
						<li>
						<a href="#">상품 정보</a></li>
						<c:if test="${currentId != null }">
						<li><a href="#">섭취 상품 정보</a></li>
						</c:if>
						<li><a href="#">질문 게시판</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<c:choose>
							<c:when test="${currentId == null }">
							<li><a class="btn btn-sm" href="signuppage"> <span
								class="glyphicon glyphicon-user" aria-hidden="true"></span> <span>&nbsp;Sign
									Up</span>
						</a></li>
						<li>
							<ul class="nav navbar-nav pull-right">
								<li class="dropdown" id="menuLogin"><a
									class="btn btn-sm dropdown-toggle" href="#"
									data-toggle="dropdown" id="navLogin"> <span
										class="glyphicon glyphicon-lock" aria-hidden="true"></span> <span>&nbsp;Login</span>
								</a>
									<div class="dropdown-menu" style="padding: 17px;">
										<form action="login" method="post">
											<input type ="hidden" name="action" value="login" />
											<div class="form-group">
												<label for="id">아이디</label> <input type="email" name="id"
													class="form-control" id="id" placeholder="Email">
											</div>
											<div class="form-group">
												<label for="pw">패스워드</label> <input type="password" name="password"
													class="form-control" id="password" placeholder="Password">
											</div>
											<div class="form-group">
												<button type="submit" class="btn btn-block btn-primary">로그인</button>
											</div>
										</form>
										<a href="./findPassword.jsp" class="btn btn-block btn-warning">비밀번호 찾기</a> 
											<a href="./updatepersonalinfo.jsp"
											class="btn btn-block btn-info"> 회원정보 수정 </a>
                                             <a href= "#" class="btn btn-block btn-danger">회원정보
											삭제 </a>
									</div></li>
							</ul>
						</li>
							</c:when>
							<c:when test="${currentId != null }">
							<li>
								<a id="modalbtn" class="btn btn-sm"> <span
								class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> <span>&nbsp; 오늘 뭐먹지? </span>
								</a>
							</li>
							<li><a class="btn btn-sm" href="memlist?id=${currentId }"> <span
								class="glyphicon glyphicon-user" aria-hidden="true"></span> <span>&nbsp;ID : ${currentId }</span>
						</a></li>
							<li><a class="btn btn-sm" href="logoutmem"> <span
								class="glyphicon glyphicon-off" aria-hidden="true"></span> <span>&nbsp;Log Out</span>
						</a></li>
							</c:when>
						</c:choose>
						
					</ul>

				</div>
			</div>
		</nav>
	
		<div class="jumbotron">
			<h1>
				WHAT WE <strong style="color: #4d7d5a;">PROVIDE</strong>
			</h1>
			<hr>
			<p>건강한 삶을 위한 먹거리 프로젝트</p>
		</div>
    <h1 style="text-align: center; font-size: 3em; margin-bottom:"> 질문 게시판 </h1>
		<hr style="margin-bottom: 40px;">

		<div class="panel panel-default">
			<div class="panel-body">
				<form action="updateboard" method="post">
					<input type="hidden" name="user_id" value="${currentId }" />
					<div class="form-group">
						<label for="title">제목</label>
						<input type="hidden" name="bid" value="${bid }" />
						<input id="title" name="btitle" type="text" class="form-control" v-model="customer.cname" value="${ }">
					</div>
					<div class="form-group">
						<label for="ncontent">내용</label>
						<textarea id="bcontent" name="bcontent" class="form-control" rows="15">${bcontent }</textarea>
					</div>
					
					<div class="row">
						<div class="col-sm-12 text-right">
							<button class="btn btn-info btn-flat" @click="submit()">등록</button>
						</div>
					</div>
				</form>
			</div>
		</div>
</div>
</template>


<script>

export default {
    name : "updateboard",
    props: ["id"],
      data() {
    return {
      info: null,
      loading: true,
      errored: false,
      deps: null,
      titls: null,
      customer: {
        commission_pct: 0,
        dept_id: 0,
        mailid: "",
        manager_id: 0,
        cname: "",
        salary: 0,
        start_date: "",
        title: ""
      },
      submitted: false
    };
  },

mounted() {
   
  },
  methods: {
    show_detail: function() {
      alert(this.id + "상세보기");
      //아래를 수정했다.
      this.$router.push("/detailcustomer/" + this.id);
    },
    
    newCustomer() {
      (this.submitted = false),
        (this.info = null),
        (this.loading = true),
        (this.errored = false),
        (this.deps = null),
        (this.titls = null),
        (this.customer = {
          commission_pct: 0,
          dept_id: 0,
          mailid: "",
          manager_id: 0,
          cname: "",
          salary: 0,
          start_date: "",
          title: ""
        });
    }
  }
};
</script>

  
}
