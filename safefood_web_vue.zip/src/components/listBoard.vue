<template>
 <div class="container">
	<h1 style="text-align: center; font-size: 3em; margin-bottom:">질문 게시판</h1>
		<hr style="margin-bottom: 40px;">

		<div class="panel panel-default">
			<div class="panel-body">
				<table class="table text-center table-bordered table-hover">
					<thead>
						<tr>
							<th>번호</th>
							<th>제목</th>
							<th>작성자</th>
							<th>조회수</th>
						</tr>
					</thead>
           <tr v-for="user in list" class="#" :key="user.bid">
            <td v-html="user.bid" @click="show_detail(user.bid)"></td>
            <td v-html="user.btitle"></td>
            <td v-html="user.user_id"></td>
            <td v-html="user.bcount"></td>
      
        </tr>
				
				</table>
				<div class="row">
					<div class="col-sm-12 text-right">
						<a href="boardinsertpage" class="btn btn-info btn-flat">글쓰기</a>
					</div>
				</div>
			</div>
		</div>
		<footer style="background: #ececec; padding: 50px;">
		<h1>Find Us</h1>
		<hr>
		<p>
			<i class="glyphicon glyphicon-envelope"></i> (SSAFY) 서울시 강남구 테헤란로
			멀티스퀘어
		</p>
		<p>
			<i class="glyphicon glyphicon-envelope"></i> 1544-9001
		</p>
		<p>
			<i class="glyphicon glyphicon-envelope"></i> admin@ssafy.com
		</p>
	</footer>
</div>
</template>

<script>
import http from "../http-common";
export default {
  name: "board-list",
  data() {
    return {
      upHere: false,
      list: [],
      loading: true,
      errored: false
    };
  },
  methods: {
    retrieveBoards() {
      http
        .get("/listboard")
        .then(response => (this.list = response.data['resvalue']))
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    refreshList() {
      this.retrieveBoards();
    },
    show_detail: function(userid) {
      alert(userid + "상세보기");
      //아래를 수정했다.
      this.$router.push("/infoboard/" + userid);
    }
  },
  filters: {

  },
  mounted() {
    this.retrieveBoards();
  }
};
</script>

<style>
</style>
