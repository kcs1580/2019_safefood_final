<template>
<div id="app">
<div class='headtitle'><h2>SSAFY HRM LIST</h2></div>
<div class='search_box'>
 <nav>
        
        <router-link class="btn btn-primary" to="/add">사원추가</router-link> |
        <router-link class="btn btn-primary" to="/chartpiecustomer">부서별 인원보기2</router-link> |
        <router-link class="btn btn-primary" to="/updateboard">글 수정하기</router-link>
        <router-link class="btn btn-primary" to="/insertboard">게시판 입력</router-link>
        <router-link class="btn btn-primary" to="/listboard">게시판 목록</router-link>

 </nav>
</div>
        <router-view/>
</div>
</template>

<script>
export default {
  name: "app"
};
</script>

<style>

</style>
