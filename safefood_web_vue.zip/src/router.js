import Vue from "vue";
import Router from "vue-router";
import UpdateBoard from "./components/UpdateBoard.vue";
import InsertBoard from "./components/InsertBoard.vue";
import listBoard from "./components/listBoard.vue";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [ 
    {
      path: '/updateboard',
      name: 'updateboard',
      component: UpdateBoard,
      props: true,
    },
    {
      path: '/insertboard',
      name: 'insertboard',
      component: InsertBoard
    }
    ,
    {
      path: "/listboard",
      name: "listboard",
      alias: "/listboard",
      component: listBoard
    }
  ]
});